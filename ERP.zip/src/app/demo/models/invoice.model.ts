export class Invoice {
    invoiceno: string = "";
    grdate: string = "";
    invoicedate: string = "";
    wareocode: string = "";
    cbm: string = "";
    purchaseqty: string = "";
    unitprice: string = "";
    exchvalue: string = "";
    customs: string = "";
    customduty: string = "";
}