import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainten-error',
  templateUrl: './mainten-error.component.html',
  styleUrls: ['./mainten-error.component.scss']
})
export class MaintenErrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
