import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tbl-sizing',
  templateUrl: './tbl-sizing.component.html',
  styleUrls: ['./tbl-sizing.component.scss']
})
export class TblSizingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
