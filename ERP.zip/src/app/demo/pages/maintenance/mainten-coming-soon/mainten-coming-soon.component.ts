import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainten-coming-soon',
  templateUrl: './mainten-coming-soon.component.html',
  styleUrls: ['./mainten-coming-soon.component.scss']
})
export class MaintenComingSoonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
