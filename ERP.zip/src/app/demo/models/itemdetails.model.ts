export class ItemDetails {
    
    MarketPlace: string = "";
    ItemSKU: string = "";
    ItemName: string = "";
    RetailPrice: string = "";
    OrderedQty: string = "";
    Paidamount: string = "";
    PaymentMethod: string = "";
    SNNumber: string = "";

}

							
