				
		

					
    export class OrderDetails {
        
        OrderNumber: string = "";
        OrderDate: string = "";
        Check: string = "";
        OrderStatus:string ="";
        UpdatedDate: string = "";
        Checked:boolean = false;
    }