import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-typography',
  templateUrl: './basic-typography.component.html',
  styleUrls: ['./basic-typography.component.scss']
})
export class BasicTypographyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
